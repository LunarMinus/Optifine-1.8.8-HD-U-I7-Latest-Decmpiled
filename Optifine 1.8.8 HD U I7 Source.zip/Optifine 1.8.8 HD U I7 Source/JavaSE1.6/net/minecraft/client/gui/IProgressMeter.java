package net.minecraft.client.gui;

public interface IProgressMeter
{
    String[] lanSearchStates = new String[] {"oooooo", "Oooooo", "oOoooo", "ooOooo", "oooOoo", "ooooOo", "oooooO"};

    void doneLoading();
}
